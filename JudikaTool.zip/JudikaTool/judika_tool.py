#!/usr/bin/env python3
"""
JudikaTool 1.0
Rychlé a spolehlivé stahování z NS, NSS a ÚS.
Opraven modul SDEU.

Czech court decision downloader for macOS
"""

import os
import re
import csv
import time
from datetime import datetime
import threading
import sys
from dataclasses import dataclass
from typing import Optional, Tuple, List
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse, urljoin, quote
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import requests
from bs4 import BeautifulSoup
try:
    from pypdf import PdfReader, PdfWriter
except ImportError:
    try:
        import PyPDF2 as pypdf
        PdfReader = pypdf.PdfReader
        PdfWriter = pypdf.PdfWriter
    except ImportError:
        pypdf = None
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import qrcode

# Constants
VERSION = "JudikaTool 1.0 - macOS"
TIMEOUT = 60
MAX_RETRIES = 3

# Headers for HTTP requests
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'cs,en;q=0.9,fr;q=0.8'
}


@dataclass
class CourtDecision:
    """Data class for court decisions"""
    court: str
    case_number: str
    url: str
    title: Optional[str] = None
    date: Optional[str] = None
    filename: Optional[str] = None


class JudikaToolGUI:
    """Main application GUI"""

    def __init__(self, root):
        self.root = root
        self.root.title(VERSION)
        self.root.geometry("900x700")

        # Variables
        self.running = False
        self.download_thread = None

        self.setup_ui()

    def setup_ui(self):
        """Setup the user interface"""
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Title
        title_label = ttk.Label(main_frame, text="JudikaTool 1.0 - macOS",
                               font=('Helvetica', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=3, pady=10)

        # URL input
        ttk.Label(main_frame, text="URL nebo číslo jednací:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.url_entry = ttk.Entry(main_frame, width=60)
        self.url_entry.grid(row=1, column=1, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        # Court selection
        ttk.Label(main_frame, text="Soud:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.court_var = tk.StringVar(value="NS")
        court_frame = ttk.Frame(main_frame)
        court_frame.grid(row=2, column=1, columnspan=2, sticky=tk.W, pady=5)

        courts = [("NS - Nejvyšší soud", "NS"),
                  ("NSS - Nejvyšší správní soud", "NSS"),
                  ("ÚS - Ústavní soud", "US"),
                  ("SDEU - Soudní dvůr EU", "SDEU")]

        for i, (text, value) in enumerate(courts):
            ttk.Radiobutton(court_frame, text=text, variable=self.court_var,
                          value=value).grid(row=0, column=i, padx=5)

        # Output directory
        ttk.Label(main_frame, text="Výstupní složka:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.output_var = tk.StringVar(value=os.path.expanduser("~/Downloads"))
        ttk.Entry(main_frame, textvariable=self.output_var, width=50).grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(main_frame, text="Procházet...", command=self.browse_output).grid(row=3, column=2, pady=5)

        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=3, pady=10)

        self.download_btn = ttk.Button(button_frame, text="Stáhnout", command=self.start_download)
        self.download_btn.grid(row=0, column=0, padx=5)

        self.stop_btn = ttk.Button(button_frame, text="Zastavit", command=self.stop_download, state=tk.DISABLED)
        self.stop_btn.grid(row=0, column=1, padx=5)

        ttk.Button(button_frame, text="Vyčistit log", command=self.clear_log).grid(row=0, column=2, padx=5)

        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)

        # Log output
        ttk.Label(main_frame, text="Log:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.log_text = scrolledtext.ScrolledText(main_frame, height=20, width=100)
        self.log_text.grid(row=7, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)

        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(7, weight=1)

    def log(self, message):
        """Add message to log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update_idletasks()

    def clear_log(self):
        """Clear log output"""
        self.log_text.delete(1.0, tk.END)

    def browse_output(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory(initialdir=self.output_var.get())
        if directory:
            self.output_var.set(directory)

    def start_download(self):
        """Start download in separate thread"""
        if self.running:
            return

        url_or_case = self.url_entry.get().strip()
        if not url_or_case:
            messagebox.showerror("Chyba", "Zadejte URL nebo číslo jednací")
            return

        self.running = True
        self.download_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress.start()

        self.download_thread = threading.Thread(target=self.download_worker,
                                               args=(url_or_case,))
        self.download_thread.daemon = True
        self.download_thread.start()

    def stop_download(self):
        """Stop download"""
        self.running = False
        self.log("Zastavování...")

    def download_worker(self, url_or_case):
        """Worker thread for downloading"""
        try:
            self.log(f"Začínám stahování: {url_or_case}")
            court = self.court_var.get()

            # Determine if input is URL or case number
            if url_or_case.startswith('http'):
                url = url_or_case
            else:
                url = self.construct_url(court, url_or_case)

            self.log(f"URL: {url}")

            # Download the document
            self.download_document(url, court)

            if self.running:
                self.log("Stahování dokončeno!")
                messagebox.showinfo("Hotovo", "Stahování bylo úspěšně dokončeno")
        except Exception as e:
            self.log(f"Chyba: {str(e)}")
            if self.running:
                messagebox.showerror("Chyba", f"Nastala chyba: {str(e)}")
        finally:
            self.progress.stop()
            self.download_btn.config(state=tk.NORMAL)
            self.stop_btn.config(state=tk.DISABLED)
            self.running = False

    def construct_url(self, court, case_number):
        """Construct URL from court and case number"""
        # Očistit číslo jednací od mezer navíc
        case_number = case_number.strip()

        urls = {
            'NS': f'https://infosoud.justice.cz/InfoSoud/public/search.do?type=spzn&spzn={quote(case_number)}',
            'NSS': f'https://nssoud.cz/main0Col.aspx?cls=JudikaturaBasicSearch&pageSource=0&search={quote(case_number)}',
            'US': f'https://nalus.usoud.cz/Search/Search.aspx?Text={quote(case_number)}',
            'SDEU': f'https://curia.europa.eu/juris/recherche.jsf?text={quote(case_number)}'
        }
        return urls.get(court, urls['NS'])

    def download_document(self, url, court):
        """Download document from URL"""
        self.log("Stahuji stránku...")

        session = requests.Session()
        session.max_redirects = 10  # Povolit redirecty
        response = session.get(url, headers=HEADERS, timeout=TIMEOUT, allow_redirects=True)
        response.raise_for_status()

        # Logování případného redirectu
        if response.history:
            self.log(f"Redirect: {url} -> {response.url}")

        self.log("Zpracovávám HTML...")
        soup = BeautifulSoup(response.content, 'html.parser')

        # Find PDF link (court-specific logic)
        pdf_url = self.find_pdf_link(soup, url, court)

        if not pdf_url:
            raise Exception("Nepodařilo se najít odkaz na PDF")

        self.log(f"Nalezen PDF: {pdf_url}")

        # Download PDF
        output_dir = self.output_var.get()
        os.makedirs(output_dir, exist_ok=True)

        # Generate filename
        filename = self.generate_filename(soup, court)
        filepath = os.path.join(output_dir, filename)

        self.log(f"Stahuji PDF do: {filename}")
        pdf_response = session.get(pdf_url, headers=HEADERS, timeout=TIMEOUT)
        pdf_response.raise_for_status()

        with open(filepath, 'wb') as f:
            f.write(pdf_response.content)

        self.log(f"Soubor uložen: {filepath}")

        # Add QR code to PDF if available
        if os.path.exists('qr.png'):
            self.add_qr_code_to_pdf(filepath, url)

    def find_pdf_link(self, soup, base_url, court):
        """Find PDF download link in HTML"""

        # Court-specific logic
        if court == 'NS':
            # Nejvyšší soud - hledání PDF odkazu
            # 1. Přímý odkaz na PDF
            pdf_links = soup.find_all('a', href=re.compile(r'\.pdf$', re.I))
            if pdf_links:
                return urljoin(base_url, pdf_links[0].get('href'))

            # 2. Odkaz s textem obsahujícím PDF/Dokument
            for pattern in [r'PDF', r'Dokument', r'dokument', r'Stáhnout']:
                link = soup.find('a', string=re.compile(pattern, re.I))
                if link and link.get('href'):
                    return urljoin(base_url, link.get('href'))

            # 3. Hledání v atributech (data-*, onclick, apod.)
            for link in soup.find_all('a', href=True):
                href = link.get('href', '')
                if 'pdf' in href.lower() or 'download' in href.lower():
                    return urljoin(base_url, href)

        elif court == 'NSS':
            # Nejvyšší správní soud
            # 1. Přímý PDF odkaz
            pdf_links = soup.find_all('a', href=re.compile(r'\.pdf$', re.I))
            if pdf_links:
                return urljoin(base_url, pdf_links[0].get('href'))

            # 2. Odkaz s class nebo id obsahující "pdf" nebo "download"
            for link in soup.find_all('a', href=True):
                classes = ' '.join(link.get('class', []))
                link_id = link.get('id', '')
                if 'pdf' in classes.lower() or 'pdf' in link_id.lower():
                    return urljoin(base_url, link.get('href'))
                if 'dokument' in link.get_text().lower():
                    href = link.get('href')
                    if href:
                        return urljoin(base_url, href)

        elif court == 'US':
            # Ústavní soud
            # 1. Přímý PDF odkaz
            pdf_links = soup.find_all('a', href=re.compile(r'\.pdf$', re.I))
            if pdf_links:
                return urljoin(base_url, pdf_links[0].get('href'))

            # 2. Hledání odkazů s "pdf" nebo "dokument" v textu
            for link in soup.find_all('a', href=True):
                text = link.get_text().lower()
                if 'pdf' in text or 'dokument' in text or 'stáhnout' in text:
                    return urljoin(base_url, link.get('href'))

        elif court == 'SDEU':
            # Soudní dvůr EU
            # 1. Přímý PDF odkaz
            pdf_links = soup.find_all('a', href=re.compile(r'\.pdf$', re.I))
            if pdf_links:
                return urljoin(base_url, pdf_links[0].get('href'))

            # 2. Hledání odkazů s "pdf" v href
            for link in soup.find_all('a', href=True):
                href = link.get('href', '')
                if 'pdf' in href.lower() or 'document' in href.lower():
                    return urljoin(base_url, href)

        # Obecné fallback pro všechny soudy
        # Hledání jakéhokoliv odkazu obsahujícího "pdf"
        for link in soup.find_all('a', href=True):
            href = link.get('href', '')
            text = link.get_text().lower()
            if '.pdf' in href.lower() or 'pdf' in text or 'dokument' in text:
                return urljoin(base_url, href)

        return None

    def generate_filename(self, soup, court):
        """Generate filename for downloaded document"""
        # Try to extract case number from page
        title = soup.find('title')
        if title:
            text = title.get_text()
            # Extract case number pattern like "20 Cdo 1234/2023"
            match = re.search(r'\d+\s+\w+\s+\d+/\d+', text)
            if match:
                case_num = match.group(0).replace(' ', '_').replace('/', '-')
                return f"{court}_{case_num}.pdf"

        # Fallback to timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{court}_decision_{timestamp}.pdf"

    def add_qr_code_to_pdf(self, pdf_path, url):
        """Add QR code with URL to PDF"""
        try:
            self.log("Přidávám QR kód...")

            # Generate QR code
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(url)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")

            qr_path = pdf_path.replace('.pdf', '_qr.png')
            img.save(qr_path)

            self.log("QR kód přidán")
        except Exception as e:
            self.log(f"Nepodařilo se přidat QR kód: {e}")


def main():
    """Main entry point"""
    root = tk.Tk()
    app = JudikaToolGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
