#!/bin/bash
# Installation script for JudikaTool on macOS

echo "Installing JudikaTool dependencies..."

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed. Please install Python 3 first."
    exit 1
fi

# Install requirements
python3 -m pip install --user -r requirements.txt

echo ""
echo "Installation complete!"
echo "To run JudikaTool, execute: python3 judika_tool.py"
echo "Or make it executable: chmod +x judika_tool.py && ./judika_tool.py"
